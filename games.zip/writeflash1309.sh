#!/bin/bash
python flashcart-writer-1309.py games-image.bin

