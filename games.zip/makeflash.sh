#!/bin/bash
python flashcart-builder.py games.csv

